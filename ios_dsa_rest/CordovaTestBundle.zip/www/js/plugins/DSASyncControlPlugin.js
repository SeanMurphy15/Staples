/**
 * DSASyncControlPlugin
 *  
 * DSASyncControlPlugin Instance plugin
 * Copyright (c) ModelMetrics 2013
 * Created by Alexey Bilous
 *
 */
 
var DSASyncControlPlugin = function() {
    
}

window.get = function(str, callback, err) {
    console.log("getDSASynchronizedDataPlugin");
    cordova.exec(callback, err, "DSASyncControlPlugin", "get", [str]);
}

window.search = function(str, callback, err) {
    console.log("searchDSASynchronizedDataPlugin");
    cordova.exec(callback, err, "DSASyncControlPlugin", "search", [str]);
}

window.upsert = function(str, callback, err) {
    console.log("upsertDSASynchronizedDataPlugin");
    cordova.exec(callback, err, "DSASyncControlPlugin", "upsert", [str]);
}

Cordova.addConstructor(function() {
    if(!window.plugins)
    {
        window.plugins = {};
    }
    window.plugins.DSASyncControlPlugin = new DSASynchronizedDataPlugin();
});
